package test;

import java.util.ArrayList;

public interface TestService {
	
	public ArrayList<TestVO> getList() throws Exception;

}
