package board.notice;

import java.sql.Timestamp;

import util.Parameter;

public class NoticeVO extends Parameter {

	private int no; // 글 번호
	private String writer; // 작성자
	private String title; // 글 제목
	private String contents; // 내용
	private Timestamp registdate; // 작성일

	private String filename_org; // 첨부파일 이름 [사용자]
	private String filename; // 첨부파일 이름 [시스템 처리용]

	private String filename_chk;

	public NoticeVO() {
		super.setPageRows(10);
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Timestamp getRegistdate() {
		return registdate;
	}

	public void setRegistdate(Timestamp registdate) {
		this.registdate = registdate;
	}

	public String getFilename_org() {
		return filename_org;
	}

	public void setFilename_org(String filename_org) {
		this.filename_org = filename_org;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFilename_chk() {
		return filename_chk;
	}

	public void setFilename_chk(String filename_chk) {
		this.filename_chk = filename_chk;
	}

}
